"""
Build the complete O2C Graph Intelligence HTML application.
Embeds full dataset + graph, uses Groq API for NL queries.
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, '..', 'data')
OUT_DIR = HERE  # output src/index.html

with open(os.path.join(DATA_DIR, 'full_dataset.json')) as f:
    raw_data = f.read()

with open(os.path.join(DATA_DIR, 'graph.json')) as f:
    graph_data = f.read()

SCHEMA = """
## SAP Order-to-Cash Dataset — Complete Schema

### Table: sales_order_headers (100 records)
Fields: salesOrder(PK), salesOrderType, salesOrganization, distributionChannel, organizationDivision,
salesGroup, salesOffice, soldToParty(FK→customers), creationDate, createdByUser, lastChangeDateTime,
totalNetAmount, overallDeliveryStatus(A=Not Delivered,B=Partial,C=Fully Delivered),
overallOrdReltdBillgStatus(empty=Not Billed,A=Not Billed,B=Partial,C=Fully Billed),
overallSdDocReferenceStatus, transactionCurrency, pricingDate, requestedDeliveryDate,
headerBillingBlockReason, deliveryBlockReason, incotermsClassification, incotermsLocation1,
customerPaymentTerms, totalCreditCheckStatus

### Table: sales_order_items (167 records)
Fields: salesOrder(FK→sales_order_headers), salesOrderItem(PK with salesOrder), salesOrderItemCategory,
material(FK→product_descriptions), requestedQuantity, requestedQuantityUnit, transactionCurrency,
netAmount, materialGroup, productionPlant(FK→plants), storageLocation, salesDocumentRjcnReason,
itemBillingBlockReason

### Table: outbound_delivery_headers (86 records)
Fields: deliveryDocument(PK), shippingPoint(FK→plants), creationDate, creationTime,
actualGoodsMovementDate, actualGoodsMovementTime, deliveryBlockReason, headerBillingBlockReason,
hdrGeneralIncompletionStatus, overallGoodsMovementStatus(A=Not Started,B=Partial,C=Complete),
overallPickingStatus(A=Not Started,B=Partial,C=Complete), overallProofOfDeliveryStatus, lastChangeDate
NOTE: Deliveries link to sales orders via customer (soldToParty matches), and to billing docs via customer.

### Table: billing_document_cancellations (80 records) — These are SAP Billing/Invoice documents
Fields: billingDocument(PK), billingDocumentType(F2=Invoice), creationDate, creationTime,
lastChangeDateTime, billingDocumentDate, billingDocumentIsCancelled, cancelledBillingDocument,
totalNetAmount, transactionCurrency, companyCode, fiscalYear, accountingDocument(FK→journal_entries),
soldToParty(FK→customers)

### Table: journal_entry_items_accounts_receivable (123 records)
Fields: companyCode, fiscalYear, accountingDocument(PK), accountingDocumentItem,
glAccount, referenceDocument(FK→billingDocument — THIS IS THE KEY LINK), costCenter, profitCenter,
transactionCurrency, amountInTransactionCurrency, companyCodeCurrency, amountInCompanyCodeCurrency,
postingDate, documentDate, accountingDocumentType, assignmentReference, lastChangeDateTime,
customer(FK), financialAccountType, clearingDate, clearingAccountingDocument, clearingDocFiscalYear

### Table: payments_accounts_receivable (120 records)
Fields: companyCode, fiscalYear, accountingDocument(FK→journal_entries), accountingDocumentItem,
clearingDate, clearingAccountingDocument, clearingDocFiscalYear, amountInTransactionCurrency,
transactionCurrency, amountInCompanyCodeCurrency, companyCodeCurrency, customer(FK),
invoiceReference, invoiceReferenceFiscalYear, salesDocument(FK→sales_orders), salesDocumentItem,
postingDate, documentDate, assignmentReference, glAccount, financialAccountType, profitCenter, costCenter

### Table: business_partners (8 records)
Fields: businessPartner(PK), customer(FK), businessPartnerCategory, businessPartnerFullName,
businessPartnerGrouping, businessPartnerName, correspondenceLanguage, createdByUser, creationDate,
firstName, formOfAddress, industry, lastChangeDate, lastName, organizationBpName1, organizationBpName2,
businessPartnerIsBlocked, isMarkedForArchiving

### Table: customer_company_assignments (8 records)
Fields: customer(FK), companyCode, accountingClerk, accountingClerkFaxNumber, accountingClerkInternetAddress,
accountingClerkPhoneNumber, alternativePayerAccount, paymentBlockingReason, paymentMethodsList,
paymentTerms, reconciliationAccount, deletionIndicator, customerAccountGroup

### Table: customer_sales_area_assignments (28 records)
Fields: customer(FK), salesOrganization, distributionChannel, division, billingIsBlockedForCustomer,
completeDeliveryIsDefined, creditControlArea, currency, customerPaymentTerms, deliveryPriority,
incotermsClassification, incotermsLocation1, salesGroup, salesOffice, shippingCondition,
slsUnlmtdOvrdelivIsAllwd, supplyingPlant, salesDistrict, exchangeRateType

### Table: plants (44 records)
Fields: plant(PK), plantName, valuationArea, plantCustomer, plantSupplier, factoryCalendar,
defaultPurchasingOrganization, salesOrganization, addressId, plantCategory, distributionChannel,
division, language, isMarkedForArchiving

### Table: product_descriptions (69 records)
Fields: product(PK=material), language, productDescription

### Table: product_plants (200 records)
Fields: product(FK), plant(FK), countryOfOrigin, regionOfOrigin, productionInvtryManagedLoc,
availabilityCheckType, fiscalYearVariant, profitCenter, mrpType

### Table: product_storage_locations (16723 records)
Fields: product(FK), plant(FK), storageLocation, physicalInventoryBlockInd, dateOfLastPostedCntUnRstrcdStk

### KEY RELATIONSHIPS:
1. Customer ← sales_order_headers.soldToParty = business_partners.customer
2. SalesOrder → SalesOrderItem: sales_order_items.salesOrder = sales_order_headers.salesOrder
3. SalesOrderItem → Product: sales_order_items.material = product_descriptions.product
4. SalesOrderItem → Plant: sales_order_items.productionPlant = plants.plant
5. Delivery → Plant: outbound_delivery_headers.shippingPoint = plants.plant
6. BillingDoc → Customer: billing_document_cancellations.soldToParty = business_partners.customer
7. JournalEntry → BillingDoc: journal_entry_items_accounts_receivable.referenceDocument = billing_document_cancellations.billingDocument
8. JournalEntry → BillingDoc (also): journal_entry_items_accounts_receivable.accountingDocument = billing_document_cancellations.accountingDocument
9. Payment → JournalEntry: payments_accounts_receivable.accountingDocument = journal_entry_items_accounts_receivable.accountingDocument
10. Payment → Customer: payments_accounts_receivable.customer = business_partners.customer
11. Product → Plant: product_plants.product = sales_order_items.material AND product_plants.plant = plants.plant
12. Product → StorageLocation: product_storage_locations.product + plant

### O2C FLOW: Customer → Sales Order → Sales Order Items → (Delivery) → Billing Document → Journal Entry → Payment

### BROKEN FLOW PATTERNS:
- Delivered but not billed: overallDeliveryStatus='C' AND overallOrdReltdBillgStatus != 'C'
- Billed but no payment: billingDocument in billing_document_cancellations but accountingDocument not in payments
- Cancelled invoices: billingDocumentIsCancelled = true
- Blocked deliveries: deliveryBlockReason != '' OR headerBillingBlockReason != ''
"""

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>O2C Graph Intelligence — Order to Cash</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600&family=Inter:wght@300;400;500;600;700&display=swap');
:root {
  --bg: #080b12; --surface: #0d1117; --surface2: #161b27; --surface3: #1c2333;
  --border: #21293b; --border2: #2d3748;
  --text: #cdd9e5; --text2: #768390; --text3: #444d56;
  --accent: #2f81f7; --accent2: #1f6feb; --accent3: #388bfd;
  --green: #3fb950; --red: #f85149; --yellow: #d29922; --purple: #bc8cff;
  --cyan: #39d3f0; --orange: #fb8500; --pink: #e44c9a;
  --nc: #3fb950; --nso: #2f81f7; --nsoi: #7b68ee; --ndel: #d29922;
  --nbill: #bc8cff; --nje: #39d3f0; --npay: #e44c9a; --nprod: #fb8500; --nplant: #77c152;
}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;height:100vh;overflow:hidden;display:flex;flex-direction:column}
/* HEADER */
.hdr{display:flex;align-items:center;padding:0 16px;height:48px;border-bottom:1px solid var(--border);background:var(--surface);flex-shrink:0;gap:12px;z-index:100}
.hdr-logo{font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:600;color:var(--accent);letter-spacing:.04em;display:flex;align-items:center;gap:6px}
.hdr-logo svg{width:18px;height:18px}
.hdr-sep{color:var(--border2);font-size:20px;font-weight:200}
.hdr-title{font-size:13px;font-weight:500;color:var(--text2)}
.hdr-right{margin-left:auto;display:flex;align-items:center;gap:8px}
.stat-chip{display:flex;align-items:center;gap:5px;padding:3px 10px;border:1px solid var(--border2);border-radius:20px;font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text3)}
.stat-chip strong{color:var(--text2)}
.status-dot{width:6px;height:6px;border-radius:50%;background:var(--green);box-shadow:0 0 6px var(--green)}
/* API BAR */
.api-bar{display:flex;align-items:center;gap:10px;padding:7px 16px;background:#090d14;border-bottom:1px solid var(--border);flex-shrink:0}
.api-bar label{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--text3);white-space:nowrap;text-transform:uppercase;letter-spacing:.06em}
.api-bar input{background:var(--surface2);border:1px solid var(--border2);border-radius:4px;padding:4px 10px;font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text);outline:none;width:360px}
.api-bar input:focus{border-color:var(--accent)}
.api-key-hint{font-size:10px;color:var(--text3)}
.api-key-hint a{color:var(--accent);text-decoration:none}
/* MAIN */
.main{display:flex;flex:1;overflow:hidden}
/* GRAPH */
.graph-wrap{flex:1;position:relative;overflow:hidden;background:var(--bg)}
canvas{position:absolute;top:0;left:0;cursor:grab}
canvas:active{cursor:grabbing}
/* GRAPH CONTROLS */
.gc{position:absolute;top:12px;left:12px;display:flex;flex-direction:column;gap:5px;z-index:10}
.gc-btn{background:var(--surface);border:1px solid var(--border2);color:var(--text2);border-radius:5px;width:30px;height:30px;cursor:pointer;font-size:15px;display:flex;align-items:center;justify-content:center;transition:all .15s}
.gc-btn:hover{background:var(--surface2);color:var(--text);border-color:var(--accent)}
/* FILTER BAR */
.filter-bar{position:absolute;top:12px;left:54px;display:flex;gap:4px;flex-wrap:wrap;max-width:65%;z-index:10}
.fc{font-size:10px;font-family:'JetBrains Mono',monospace;padding:3px 8px;border-radius:3px;border:1px solid var(--border);cursor:pointer;transition:all .15s;color:var(--text3);background:var(--surface)}
.fc.on{color:#fff;border-color:transparent}
/* LEGEND */
.legend{position:absolute;bottom:12px;left:12px;background:rgba(13,17,23,.92);border:1px solid var(--border);border-radius:7px;padding:10px 12px;z-index:10;backdrop-filter:blur(8px)}
.legend-grid{display:grid;grid-template-columns:1fr 1fr;gap:4px 14px}
.li{display:flex;align-items:center;gap:5px;font-size:10px;color:var(--text2);font-family:'JetBrains Mono',monospace}
.ld{width:7px;height:7px;border-radius:50%;flex-shrink:0}
/* TOOLTIP */
.tt{position:absolute;background:var(--surface);border:1px solid var(--accent);border-radius:7px;padding:11px 13px;min-width:210px;max-width:280px;z-index:50;pointer-events:none;box-shadow:0 8px 32px rgba(0,0,0,.7);display:none}
.tt-type{font-family:'JetBrains Mono',monospace;font-size:9px;font-weight:600;color:var(--accent);text-transform:uppercase;letter-spacing:.1em;margin-bottom:5px}
.tt-title{font-size:12px;font-weight:600;color:var(--text);margin-bottom:7px}
.tt-prop{display:flex;justify-content:space-between;gap:6px;font-size:10px;margin-bottom:2px}
.tt-k{color:var(--text3);font-family:'JetBrains Mono',monospace}
.tt-v{color:var(--text);text-align:right;word-break:break-all}
/* CHAT PANEL */
.chat{width:400px;flex-shrink:0;border-left:1px solid var(--border);display:flex;flex-direction:column;background:var(--surface)}
.chat-hdr{padding:13px 15px;border-bottom:1px solid var(--border);background:var(--surface2)}
.chat-hdr-title{font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:600;color:var(--text)}
.chat-hdr-sub{font-size:10px;color:var(--text3);margin-top:2px}
/* QUICK QUERIES */
.quick{padding:8px 10px;border-bottom:1px solid var(--border);background:var(--bg)}
.quick-label{font-size:9px;font-family:'JetBrains Mono',monospace;color:var(--text3);text-transform:uppercase;letter-spacing:.08em;margin-bottom:5px}
.quick-btns{display:flex;flex-wrap:wrap;gap:4px}
.qb{font-size:9px;padding:3px 7px;background:var(--surface2);border:1px solid var(--border2);border-radius:3px;color:var(--text2);cursor:pointer;font-family:'JetBrains Mono',monospace;transition:all .15s;line-height:1.4}
.qb:hover{border-color:var(--accent);color:var(--accent3)}
/* MESSAGES */
.msgs{flex:1;overflow-y:auto;padding:10px;display:flex;flex-direction:column;gap:8px}
.msgs::-webkit-scrollbar{width:3px}
.msgs::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}
.msg{display:flex;flex-direction:column;gap:3px;animation:fi .2s ease}
@keyframes fi{from{opacity:0;transform:translateY(3px)}to{opacity:1;transform:none}}
.msg-u{align-items:flex-end}
.msg-a{align-items:flex-start}
.bubble{padding:8px 11px;border-radius:7px;font-size:12px;line-height:1.6;max-width:93%}
.msg-u .bubble{background:var(--accent2);color:#fff;border-bottom-right-radius:2px}
.msg-a .bubble{background:var(--surface2);color:var(--text);border-bottom-left-radius:2px;border:1px solid var(--border2)}
.msg-role{font-size:9px;color:var(--text3);font-family:'JetBrains Mono',monospace;padding:0 3px;text-transform:uppercase}
/* SQL/CODE block */
.code-block{background:#050810;border:1px solid var(--border2);border-left:2px solid var(--accent);border-radius:4px;padding:8px 10px;font-family:'JetBrains Mono',monospace;font-size:10px;color:#79c0ff;margin:5px 0;overflow-x:auto;white-space:pre-wrap;word-break:break-all;max-height:120px;overflow-y:auto}
.result-tbl{width:100%;border-collapse:collapse;font-size:10px;font-family:'JetBrains Mono',monospace;margin:5px 0}
.result-tbl th{text-align:left;padding:3px 5px;color:var(--text3);border-bottom:1px solid var(--border2);font-weight:500;font-size:9px}
.result-tbl td{padding:3px 5px;color:var(--text2);border-bottom:1px solid #0d1117;font-size:10px}
.result-tbl tr:hover td{background:var(--surface3)}
.insight{margin-top:7px;padding:6px 8px;background:rgba(47,129,247,.08);border:1px solid rgba(47,129,247,.2);border-radius:4px;font-size:11px;color:var(--text2)}
.insight-icon{color:var(--accent);margin-right:4px}
.err-msg{color:var(--red);font-size:11px;padding:4px 0}
.scalar-result{font-family:'JetBrains Mono',monospace;font-size:22px;font-weight:600;color:var(--accent);padding:8px 0}
/* Thinking */
.thinking{display:flex;align-items:center;gap:8px;padding:7px 11px;font-size:11px;color:var(--text3);font-family:'JetBrains Mono',monospace}
.dots{display:flex;gap:3px}
.dot{width:4px;height:4px;border-radius:50%;background:var(--accent);animation:pu 1.2s infinite}
.dot:nth-child(2){animation-delay:.2s}.dot:nth-child(3){animation-delay:.4s}
@keyframes pu{0%,100%{opacity:.2}50%{opacity:1}}
/* INPUT */
.input-area{padding:10px;border-top:1px solid var(--border);background:var(--surface2);display:flex;gap:7px;align-items:flex-end}
.chat-input{flex:1;background:var(--surface);border:1px solid var(--border2);border-radius:6px;padding:7px 11px;color:var(--text);font-size:12px;font-family:'Inter',sans-serif;outline:none;resize:none;min-height:36px;max-height:100px;line-height:1.5}
.chat-input:focus{border-color:var(--accent)}
.chat-input::placeholder{color:var(--text3)}
.send{background:var(--accent);border:none;border-radius:6px;width:34px;height:34px;cursor:pointer;color:#fff;font-size:14px;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s}
.send:hover{background:var(--accent3)}
.send:disabled{background:var(--border2);cursor:not-allowed}
/* Highlight overlay */
.highlight-banner{position:absolute;bottom:70px;left:12px;background:rgba(47,129,247,.15);border:1px solid var(--accent);border-radius:5px;padding:5px 10px;font-size:10px;font-family:'JetBrains Mono',monospace;color:var(--accent3);z-index:10;display:none}
</style>
</head>
<body>
<div class="hdr">
  <div class="hdr-logo">
    <svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="3" fill="#2f81f7"/><circle cx="3" cy="5" r="2" fill="#3fb950"/><circle cx="17" cy="5" r="2" fill="#bc8cff"/><circle cx="3" cy="15" r="2" fill="#e44c9a"/><circle cx="17" cy="15" r="2" fill="#39d3f0"/><line x1="10" y1="10" x2="3" y2="5" stroke="#2f81f7" stroke-width=".8" opacity=".5"/><line x1="10" y1="10" x2="17" y2="5" stroke="#2f81f7" stroke-width=".8" opacity=".5"/><line x1="10" y1="10" x2="3" y2="15" stroke="#2f81f7" stroke-width=".8" opacity=".5"/><line x1="10" y1="10" x2="17" y2="15" stroke="#2f81f7" stroke-width=".8" opacity=".5"/></svg>
    O2C·GRAPH
  </div>
  <div class="hdr-sep">/</div>
  <div class="hdr-title">Order to Cash Intelligence</div>
  <div class="hdr-right">
    <div class="status-dot"></div>
    <div class="stat-chip">Nodes <strong id="nc">—</strong></div>
    <div class="stat-chip">Edges <strong id="ec">—</strong></div>
    <div class="stat-chip">Records <strong>17,756</strong></div>
  </div>
</div>
<div class="api-bar">
  <label>Groq API Key</label>
  <input type="password" id="apiKey" placeholder="gsk_..." autocomplete="off"/>
  <span class="api-key-hint">Free key at <a href="https://console.groq.com" target="_blank">console.groq.com</a> · stays in browser only</span>
</div>
<div class="main">
  <div class="graph-wrap" id="gw">
    <canvas id="gc"></canvas>
    <div class="gc">
      <button class="gc-btn" id="zi" title="Zoom In">+</button>
      <button class="gc-btn" id="zo" title="Zoom Out">−</button>
      <button class="gc-btn" id="rv" title="Reset View" style="font-size:12px">⟲</button>
      <button class="gc-btn" id="fs" title="Fit All" style="font-size:11px">⊡</button>
    </div>
    <div class="filter-bar" id="fb"></div>
    <div class="legend">
      <div class="legend-grid" id="lg"></div>
    </div>
    <div class="tt" id="tt"></div>
    <div class="highlight-banner" id="hb">● Nodes highlighted from query result</div>
  </div>
  <div class="chat">
    <div class="chat-hdr">
      <div class="chat-hdr-title">// O2C Graph Query Agent</div>
      <div class="chat-hdr-sub">Natural language → JS query → Data-grounded answers · Powered by Groq llama-3.3-70b</div>
    </div>
    <div class="quick">
      <div class="quick-label">Quick Queries</div>
      <div class="quick-btns" id="qb"></div>
    </div>
    <div class="msgs" id="msgs">
      <div class="msg msg-a">
        <div class="msg-role">Graph Agent</div>
        <div class="bubble">
          Hello! I can analyze the complete <strong>SAP Order-to-Cash</strong> dataset for you.<br><br>
          The dataset includes <strong>17,756 records</strong> across 13 tables: sales orders, deliveries, invoices, journal entries, payments, customers, products, plants, and more.<br><br>
          Ask me anything — I'll translate your question into a data query and return grounded, data-backed answers with results.<br><br>
          <em style="color:var(--text3)">Enter your Groq API key above to start.</em>
        </div>
      </div>
    </div>
    <div class="input-area">
      <textarea class="chat-input" id="ci" placeholder="Ask about orders, invoices, payments, broken flows..." rows="1"></textarea>
      <button class="send" id="sb">↑</button>
    </div>
  </div>
</div>

<script>
// ================================================================
// EMBEDDED FULL DATASET + GRAPH
// ================================================================
const DATA = DATASET_PLACEHOLDER;
const GRAPH = GRAPH_PLACEHOLDER;

const SCHEMA = `SCHEMA_PLACEHOLDER`;

// ================================================================
// GRAPH ENGINE
// ================================================================
const canvas = document.getElementById('gc');
const ctx = canvas.getContext('2d');
const wrap = document.getElementById('gw');

const COLORS = {
  Customer:'#3fb950',SalesOrder:'#2f81f7',SalesOrderItem:'#7b68ee',
  Delivery:'#d29922',BillingDoc:'#bc8cff',JournalEntry:'#39d3f0',
  Payment:'#e44c9a',Product:'#fb8500',Plant:'#77c152'
};
const RADII = {Customer:12,SalesOrder:9,BillingDoc:8,JournalEntry:7,Payment:7,Delivery:8,Product:6,SalesOrderItem:4,Plant:7};

let nodes = GRAPH.nodes.map(n=>({...n}));
let edges = GRAPH.edges;
let tr = {x:0,y:0,s:1};
let dragging=false,dragStart=null;
let hovNode=null,selNode=null;
let highlighted=new Set();
let activeTypes=new Set(Object.keys(COLORS));
let pos={},vel={};
let simStep=0,SIM_MAX=300;

// Legend
const lg=document.getElementById('lg');
Object.entries(COLORS).forEach(([t,c])=>{
  const d=document.createElement('div');d.className='li';
  d.innerHTML=`<div class="ld" style="background:${c}"></div>${t}`;
  lg.appendChild(d);
});

// Filter chips
const fb=document.getElementById('fb');
Object.entries(COLORS).forEach(([t,c])=>{
  const btn=document.createElement('button');
  btn.className='fc on';btn.dataset.t=t;
  btn.textContent=t;btn.style.color=c;
  btn.onclick=()=>{
    if(activeTypes.has(t)){activeTypes.delete(t);btn.classList.remove('on');btn.style.color='#444d56';}
    else{activeTypes.add(t);btn.classList.add('on');btn.style.color=c;}
    simStep=0;
  };
  fb.appendChild(btn);
});

// Stats
document.getElementById('nc').textContent=nodes.length;
document.getElementById('ec').textContent=edges.length;

function resize(){canvas.width=wrap.clientWidth;canvas.height=wrap.clientHeight;}

function initPos(){
  const W=canvas.width,H=canvas.height;
  const groups={};
  nodes.forEach(n=>{if(!groups[n.type])groups[n.type]=[];groups[n.type].push(n);});
  const order=['Customer','SalesOrder','Delivery','BillingDoc','JournalEntry','Payment','Product','SalesOrderItem','Plant'];
  let ti=0;
  order.forEach(type=>{
    const g=groups[type]||[];
    const cx=W*(0.12+((ti%3)*0.3)),cy=H*(0.2+(Math.floor(ti/3)*0.35));
    g.forEach((n,i)=>{
      const a=(i/Math.max(g.length,1))*Math.PI*2;
      const r=50+Math.random()*50;
      pos[n.id]={x:cx+Math.cos(a)*r,y:cy+Math.sin(a)*r};
      vel[n.id]={x:(Math.random()-.5)*2,y:(Math.random()-.5)*2};
    });
    ti++;
  });
  tr={x:W/2,y:H/2,s:0.8};
}

function step(){
  if(simStep>=SIM_MAX)return;
  simStep++;
  const alpha=Math.max(0.005,0.25*(1-simStep/SIM_MAX));
  const vis=nodes.filter(n=>activeTypes.has(n.type));
  const vidSet=new Set(vis.map(n=>n.id));
  // repulsion
  for(let i=0;i<vis.length;i++){
    for(let j=i+1;j<vis.length;j++){
      const a=vis[i],b=vis[j],pa=pos[a.id],pb=pos[b.id];
      const dx=pb.x-pa.x,dy=pb.y-pa.y;
      const d=Math.sqrt(dx*dx+dy*dy)||1;
      const f=(32*32)/(d*d);
      const fx=(dx/d)*f*alpha,fy=(dy/d)*f*alpha;
      vel[a.id].x-=fx;vel[a.id].y-=fy;
      vel[b.id].x+=fx;vel[b.id].y+=fy;
    }
  }
  // attraction
  edges.forEach(e=>{
    if(!vidSet.has(e.source)||!vidSet.has(e.target))return;
    const ps=pos[e.source],pt=pos[e.target];if(!ps||!pt)return;
    const dx=pt.x-ps.x,dy=pt.y-ps.y;
    const d=Math.sqrt(dx*dx+dy*dy)||1;
    const f=(d-90)*0.008*alpha;
    const fx=(dx/d)*f,fy=(dy/d)*f;
    vel[e.source].x+=fx;vel[e.source].y+=fy;
    vel[e.target].x-=fx;vel[e.target].y-=fy;
  });
  vis.forEach(n=>{
    const p=pos[n.id],v=vel[n.id];
    v.x*=0.88;v.y*=0.88;
    p.x+=v.x;p.y+=v.y;
  });
}

function draw(){
  const W=canvas.width,H=canvas.height;
  ctx.clearRect(0,0,W,H);
  ctx.save();
  ctx.translate(tr.x,tr.y);ctx.scale(tr.s,tr.s);
  ctx.translate(-W/2,-H/2);
  const vis=new Set(nodes.filter(n=>activeTypes.has(n.type)).map(n=>n.id));
  // edges
  edges.forEach(e=>{
    if(!vis.has(e.source)||!vis.has(e.target))return;
    const ps=pos[e.source],pt=pos[e.target];if(!ps||!pt)return;
    const hl=highlighted.size>0&&(highlighted.has(e.source)||highlighted.has(e.target));
    ctx.beginPath();ctx.moveTo(ps.x,ps.y);ctx.lineTo(pt.x,pt.y);
    if(hl){ctx.strokeStyle='rgba(47,129,247,.55)';ctx.lineWidth=1.5;}
    else if(highlighted.size>0){ctx.strokeStyle='rgba(30,36,50,.25)';ctx.lineWidth=.4;}
    else{ctx.strokeStyle='rgba(47,129,247,.1)';ctx.lineWidth=.7;}
    ctx.stroke();
  });
  // nodes
  nodes.forEach(n=>{
    if(!activeTypes.has(n.type))return;
    const p=pos[n.id];if(!p)return;
    const r=RADII[n.type]||5,c=COLORS[n.type]||'#888';
    const sel=n===selNode,hov=n===hovNode,hl=highlighted.size>0&&highlighted.has(n.id),dm=highlighted.size>0&&!highlighted.has(n.id);
    ctx.globalAlpha=dm?.18:1;
    if(sel||hov||hl){ctx.beginPath();ctx.arc(p.x,p.y,r+5,0,Math.PI*2);ctx.fillStyle=c+'25';ctx.fill();}
    ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);
    ctx.fillStyle=(sel||hl)?c:c+'bb';ctx.fill();
    if(sel||hl){ctx.strokeStyle='#fff';ctx.lineWidth=1.5;ctx.stroke();}
    ctx.globalAlpha=1;
  });
  // labels
  nodes.forEach(n=>{
    if(!activeTypes.has(n.type))return;
    const p=pos[n.id];if(!p)return;
    const r=RADII[n.type]||5;
    const sel=n===selNode,hov=n===hovNode,hl=highlighted.size>0&&highlighted.has(n.id);
    if(sel||hov||hl){
      ctx.font=`${sel?'600 ':''}9px JetBrains Mono`;
      ctx.fillStyle='#cdd9e5';ctx.textAlign='center';
      ctx.fillText(n.label.slice(0,18),p.x,p.y-r-4);
    }
  });
  ctx.restore();
}

function loop(){step();draw();requestAnimationFrame(loop);}

// Mouse
function getMP(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
function toWorld(sx,sy){const W=canvas.width,H=canvas.height;return{x:(sx-tr.x)/tr.s+W/2,y:(sy-tr.y)/tr.s+H/2};}
function nodeAt(wx,wy){
  let best=null,bd=16;
  nodes.forEach(n=>{
    if(!activeTypes.has(n.type))return;
    const p=pos[n.id];if(!p)return;
    const r=RADII[n.type]||5;
    const d=Math.sqrt((wx-p.x)**2+(wy-p.y)**2);
    if(d<Math.max(r+5,bd)){bd=d;best=n;}
  });
  return best;
}

const tt=document.getElementById('tt');
function showTT(n,sx,sy){
  if(!n){tt.style.display='none';return;}
  const props=n.props||{};
  let h=`<div class="tt-type">${n.type}</div><div class="tt-title">${n.label}</div>`;
  Object.entries(props).filter(([k,v])=>v!==''&&v!==null&&v!==undefined&&v!==false).slice(0,9).forEach(([k,v])=>{
    h+=`<div class="tt-prop"><span class="tt-k">${k}</span><span class="tt-v">${String(v).slice(0,28)}</span></div>`;
  });
  const conn=edges.filter(e=>e.source===n.id||e.target===n.id).length;
  h+=`<div class="tt-prop"><span class="tt-k">connections</span><span class="tt-v">${conn}</span></div>`;
  tt.innerHTML=h;tt.style.display='block';
  let tx=sx+12,ty=sy-12;
  if(tx+280>canvas.width)tx=sx-280-12;
  if(ty+200>canvas.height)ty=canvas.height-200;
  if(ty<0)ty=5;
  tt.style.left=tx+'px';tt.style.top=ty+'px';
}

canvas.addEventListener('mousemove',e=>{
  if(dragging){tr.x=dragStart.tx+(e.clientX-dragStart.x);tr.y=dragStart.ty+(e.clientY-dragStart.y);return;}
  const mp=getMP(e),wp=toWorld(mp.x,mp.y);
  hovNode=nodeAt(wp.x,wp.y);
  canvas.style.cursor=hovNode?'pointer':'grab';
  showTT(hovNode,mp.x,mp.y);
});
canvas.addEventListener('mousedown',e=>{
  const mp=getMP(e),wp=toWorld(mp.x,mp.y);
  const n=nodeAt(wp.x,wp.y);
  if(n){selNode=n;}
  else{dragging=true;dragStart={x:e.clientX,y:e.clientY,tx:tr.x,ty:tr.y};}
});
canvas.addEventListener('mouseup',()=>dragging=false);
canvas.addEventListener('mouseleave',()=>{dragging=false;tt.style.display='none';});
canvas.addEventListener('wheel',e=>{
  e.preventDefault();
  const mp=getMP(e);
  const factor=e.deltaY>0?.88:1.14;
  tr.s=Math.max(.05,Math.min(8,tr.s*factor));
},{passive:false});

document.getElementById('zi').onclick=()=>tr.s=Math.min(8,tr.s*1.2);
document.getElementById('zo').onclick=()=>tr.s=Math.max(.05,tr.s/1.2);
document.getElementById('rv').onclick=()=>{tr={x:canvas.width/2,y:canvas.height/2,s:.8};};
document.getElementById('fs').onclick=()=>{
  // Fit all nodes
  const vs=nodes.filter(n=>activeTypes.has(n.type)).map(n=>pos[n.id]).filter(Boolean);
  if(!vs.length)return;
  const xs=vs.map(p=>p.x),ys=vs.map(p=>p.y);
  const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
  const W=canvas.width,H=canvas.height;
  const pad=60;
  const sx=(W-pad*2)/(maxX-minX||1),sy=(H-pad*2)/(maxY-minY||1);
  tr.s=Math.min(sx,sy,.9);
  tr.x=W/2-((minX+maxX)/2)*tr.s;
  tr.y=H/2-((minY+maxY)/2)*tr.s;
};

// ================================================================
// QUERY SUGGESTIONS
// ================================================================
const SUGGESTIONS = [
  "Which products appear in the most billing documents?",
  "Trace full O2C flow for billing document 90504274",
  "Find all sales orders delivered but not yet billed",
  "Which customers have the highest total payment amounts?",
  "List all cancelled billing documents",
  "Sales orders with no delivery created",
  "Average order value by customer",
  "Which plants handle the most deliveries?",
  "Show all journal entries linked to billing document 90504219",
  "Find overdue/incomplete O2C flows by customer",
  "Products ordered most frequently across all orders",
  "Total revenue by sales organization",
  "Customers with blocked billing",
  "Show payment clearing timeline for customer 320000083",
  "Which billing docs have no corresponding payment?",
  "List all materials with their descriptions and order counts",
  "What is the total net amount of all sales orders?",
  "Show all deliveries with goods movement not completed"
];

const qbDiv=document.getElementById('qb');
SUGGESTIONS.forEach(q=>{
  const b=document.createElement('button');b.className='qb';b.textContent=q;
  b.onclick=()=>{document.getElementById('ci').value=q;send();};
  qbDiv.appendChild(b);
});

// ================================================================
// HIGHLIGHT NODES FROM QUERY RESULT
// ================================================================
function highlightResult(result){
  highlighted.clear();
  if(!result)return;
  const arr=Array.isArray(result)?result:[result];
  const nodeIndex={};
  nodes.forEach(n=>{
    const p=n.props||{};
    // Index by all key IDs
    ['salesOrder','billingDocument','deliveryDocument','accountingDocument','customer','material','product','plant'].forEach(f=>{
      const v=p[f]||n.id.replace(/^[A-Z_]+_/,'');
      if(v){
        if(!nodeIndex[f])nodeIndex[f]={};
        nodeIndex[f][v]=nodeIndex[f][v]||[];
        nodeIndex[f][v].push(n.id);
      }
    });
  });
  arr.forEach(item=>{
    if(!item||typeof item!=='object')return;
    Object.entries(item).forEach(([k,v])=>{
      if(!v)return;
      const sv=String(v);
      // Try all field maps
      const fields=['salesOrder','billingDocument','deliveryDocument','accountingDocument','customer','material','product','plant'];
      fields.forEach(f=>{
        if(nodeIndex[f]&&nodeIndex[f][sv]){
          nodeIndex[f][sv].forEach(id=>highlighted.add(id));
        }
      });
    });
  });
  // Also expand 1 hop
  const direct=new Set(highlighted);
  edges.forEach(e=>{
    if(direct.has(e.source))highlighted.add(e.target);
    if(direct.has(e.target))highlighted.add(e.source);
  });
  if(highlighted.size>0){
    const hb=document.getElementById('hb');
    hb.textContent=`● ${highlighted.size} nodes highlighted`;
    hb.style.display='block';
    setTimeout(()=>{highlighted.clear();hb.style.display='none';},10000);
  }
}

// ================================================================
// GROQ API INTEGRATION
// ================================================================
const GROQ_API='https://api.groq.com/openai/v1/chat/completions';
const MODEL='llama-3.3-70b-versatile';

const SYSTEM_PROMPT=`You are a specialized data analyst for an SAP Order-to-Cash (O2C) business process system.

IMPORTANT: You ONLY answer questions about the O2C dataset. For any unrelated requests (general knowledge, math, coding help unrelated to this data, creative writing, etc.), respond with EXACTLY:
{"offTopic":true,"message":"This system is designed to answer questions related to the Order to Cash dataset only. Please ask about sales orders, deliveries, invoices, payments, customers, or products."}

${SCHEMA}

When answering a data question, generate a JavaScript code snippet that queries the DATA object and return your answer as JSON.

The DATA object keys are: sales_order_headers, sales_order_items, outbound_delivery_headers, billing_document_cancellations, journal_entry_items_accounts_receivable, payments_accounts_receivable, business_partners, customer_company_assignments, customer_sales_area_assignments, plants, product_descriptions, product_plants, product_storage_locations

RESPONSE FORMAT (STRICT JSON, no markdown, no backticks):
{"jsCode":"return DATA.sales_order_headers.slice(0,5);","explanation":"What the query does in plain English","insight":"Key business insight from the result"}

CODING RULES:
- Must use 'return' statement
- Access data as DATA.table_name (e.g., DATA.sales_order_headers)
- All fields are strings unless noted (use parseFloat() for amounts)
- Dates are ISO strings — compare with .startsWith('2025') or slice(0,10)
- Return array of objects for tabular results, or a single number/string for aggregates
- Limit results to 20 rows max with .slice(0,20)
- For joins: use .filter() + .find() pattern
- billingDocumentIsCancelled is boolean
- overallDeliveryStatus: 'A'=not delivered, 'B'=partial, 'C'=complete
- overallOrdReltdBillgStatus: ''=not billed, 'A'=not billed, 'B'=partial, 'C'=fully billed
- IMPORTANT: journal_entry.referenceDocument = billing_doc.billingDocument (NOT accountingDocument)
- IMPORTANT: journal_entry.accountingDocument = billing_doc.accountingDocument (secondary link)
- For full O2C trace: SO → items → delivery (match via customer+date proximity) → billing (via soldToParty) → journal (referenceDocument=billingDocument) → payment (accountingDocument)

EXAMPLE QUERIES:
Q: "Which products appear in most billing documents?"
A: {"jsCode":"const itemCounts={};DATA.sales_order_items.forEach(i=>{if(!itemCounts[i.material])itemCounts[i.material]=0;itemCounts[i.material]++;});const descs={};DATA.product_descriptions.forEach(p=>{descs[p.product]=p.productDescription;});return Object.entries(itemCounts).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([m,c])=>({material:m,description:descs[m]||m,orderCount:c}));","explanation":"Counts how many times each material appears in sales order items","insight":"Top products driving sales volume"}

Q: "Trace full flow for billing document 90504274"
A: {"jsCode":"const bd=DATA.billing_document_cancellations.find(b=>b.billingDocument==='90504274');const je=DATA.journal_entry_items_accounts_receivable.filter(j=>j.referenceDocument==='90504274');const pay=DATA.payments_accounts_receivable.filter(p=>je.some(j=>j.accountingDocument===p.accountingDocument));const cust=DATA.business_partners.find(b=>b.customer===bd?.soldToParty);const so=DATA.sales_order_headers.filter(s=>s.soldToParty===bd?.soldToParty);return [{stage:'Customer',id:bd?.soldToParty,name:cust?.businessPartnerFullName||'',date:''},{stage:'BillingDoc',id:bd?.billingDocument,amount:bd?.totalNetAmount,date:bd?.billingDocumentDate?.slice(0,10),cancelled:bd?.billingDocumentIsCancelled},{stage:'JournalEntry',id:je[0]?.accountingDocument,amount:je[0]?.amountInTransactionCurrency,date:je[0]?.postingDate?.slice(0,10)},{stage:'Payment',id:pay[0]?.accountingDocument,amount:pay[0]?.amountInTransactionCurrency,date:pay[0]?.clearingDate?.slice(0,10)}];","explanation":"Traces the complete O2C flow for billing document 90504274","insight":"Shows each stage of the order-to-cash cycle for this document"}`;

let history=[];
let querying=false;

async function send(){
  const ci=document.getElementById('ci');
  const q=ci.value.trim();
  if(!q||querying)return;
  const key=document.getElementById('apiKey').value.trim();
  if(!key){addMsg('a',"Please enter your Groq API key above. Get a free key at console.groq.com");return;}
  ci.value='';ci.style.height='auto';
  addMsg('u',q);
  querying=true;document.getElementById('sb').disabled=true;
  const th=addThinking();
  history.push({role:'user',content:q});
  try{
    const resp=await fetch(GROQ_API,{
      method:'POST',
      headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},
      body:JSON.stringify({
        model:MODEL,max_tokens:2000,temperature:0.1,
        messages:[{role:'system',content:SYSTEM_PROMPT},...history.slice(-8)]
      })
    });
    const data=await resp.json();
    if(data.error)throw new Error(data.error.message||JSON.stringify(data.error));
    const raw=data.choices[0].message.content;
    history.push({role:'assistant',content:raw});
    th.remove();
    let parsed=null;
    try{
      const m=raw.match(/\{[\s\S]*\}/);
      if(m)parsed=JSON.parse(m[0]);
    }catch(e){}
    if(parsed&&parsed.offTopic){addMsg('a',parsed.message);}
    else if(parsed&&parsed.jsCode){
      let result=null,err=null;
      try{result=new Function('DATA','"use strict";'+parsed.jsCode)(DATA);}
      catch(e){err=e.message;}
      addRich(parsed,result,err);
      if(result)highlightResult(result);
    }else{addMsg('a',raw||'No response.');}
  }catch(e){
    th.remove();
    addMsg('a',`Error: ${e.message}. Check your Groq API key at console.groq.com`);
  }
  querying=false;document.getElementById('sb').disabled=false;
}

function addMsg(role,text){
  const msgs=document.getElementById('msgs');
  const d=document.createElement('div');
  d.className=`msg msg-${role}`;
  d.innerHTML=`<div class="msg-role">${role==='u'?'You':'Graph Agent'}</div><div class="bubble">${esc(text)}</div>`;
  msgs.appendChild(d);msgs.scrollTop=msgs.scrollHeight;return d;
}
function addThinking(){
  const msgs=document.getElementById('msgs');
  const d=document.createElement('div');d.className='msg msg-a';
  d.innerHTML=`<div class="msg-role">Graph Agent</div><div class="thinking"><div class="dots"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div><span>Querying dataset...</span></div>`;
  msgs.appendChild(d);msgs.scrollTop=msgs.scrollHeight;return d;
}
function addRich(parsed,result,err){
  const msgs=document.getElementById('msgs');
  const d=document.createElement('div');d.className='msg msg-a';
  let h=`<div class="msg-role">Graph Agent</div><div class="bubble">`;
  if(parsed.explanation)h+=`<p>${esc(parsed.explanation)}</p>`;
  h+=`<div class="code-block">${esc(parsed.jsCode)}</div>`;
  if(err)h+=`<p class="err-msg">⚠ Query error: ${esc(err)}</p>`;
  else if(result!==undefined&&result!==null)h+=renderResult(result);
  if(parsed.insight)h+=`<div class="insight"><span class="insight-icon">💡</span>${esc(parsed.insight)}</div>`;
  h+=`</div>`;d.innerHTML=h;
  msgs.appendChild(d);msgs.scrollTop=msgs.scrollHeight;
}
function renderResult(r){
  if(typeof r==='number'||typeof r==='string')return`<div class="scalar-result">${esc(String(r))}</div>`;
  if(!Array.isArray(r)||r.length===0)return`<p style="color:var(--text3);font-size:11px">No results found.</p>`;
  const rows=r.slice(0,20),keys=Object.keys(rows[0]||{}).slice(0,7);
  if(!keys.length)return`<p>${r.length} result(s)</p>`;
  let t=`<table class="result-tbl"><thead><tr>${keys.map(k=>`<th>${esc(k)}</th>`).join('')}</tr></thead><tbody>`;
  rows.forEach(row=>{
    t+=`<tr>${keys.map(k=>{const v=row[k];return`<td>${esc(v===null||v===undefined?'—':String(v).slice(0,35))}</td>`;}).join('')}</tr>`;
  });
  t+=`</tbody></table>`;
  if(r.length>20)t+=`<p style="color:var(--text3);font-size:10px;margin-top:3px">Showing 20 of ${r.length} rows</p>`;
  return t;
}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

// Input
document.getElementById('ci').addEventListener('keydown',e=>{
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}
});
document.getElementById('ci').addEventListener('input',function(){
  this.style.height='auto';this.style.height=Math.min(100,this.scrollHeight)+'px';
});
document.getElementById('sb').addEventListener('click',send);

// INIT
window.addEventListener('resize',()=>{resize();});
resize();
initPos();
loop();
</script>
</body>
</html>"""

# Replace placeholders with actual data
HTML = HTML.replace('DATASET_PLACEHOLDER', raw_data)
HTML = HTML.replace('GRAPH_PLACEHOLDER', graph_data)
HTML = HTML.replace('SCHEMA_PLACEHOLDER', SCHEMA.replace('`', "'"))

out_path = os.path.join(OUT_DIR, 'index.html')
with open(out_path, 'w', encoding='utf-8') as f:
    f.write(HTML)

print(f"Built: {out_path}")
print(f"Size: {os.path.getsize(out_path)//1024}KB")
