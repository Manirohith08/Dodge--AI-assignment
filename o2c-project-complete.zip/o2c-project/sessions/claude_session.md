# AI Coding Session Log — O2C Graph Intelligence

**Tool**: Claude (claude.ai)  
**Date**: 2025-03-26  
**Project**: SAP Order-to-Cash Graph-Based Query System  
**Session Duration**: ~3 hours

---

## Session Overview

This document records the complete AI-assisted development session for the O2C Graph Intelligence project. All major architectural decisions, prompts, debugging iterations, and code generation steps are documented here.

---

## Phase 1: Dataset Exploration & Schema Analysis

### Prompt 1 — Dataset Extraction
```
i have attached the dataset and gave everything complete this project accordingly without any errors
[uploaded: sap-order-to-cash-dataset.zip, Query.png, image.png, assignment PDF]
```

**AI Action:**
- Unzipped dataset, discovered 13 JSONL folders
- Loaded all records and printed schemas

**Output:**
```
billing_document_cancellations: 80 records
business_partners: 8 records
customer_company_assignments: 8 records
customer_sales_area_assignments: 28 records
journal_entry_items_accounts_receivable: 123 records
outbound_delivery_headers: 86 records
payments_accounts_receivable: 120 records
plants: 44 records
product_descriptions: 69 records
product_plants: 200 records
product_storage_locations: 16723 records
sales_order_headers: 100 records
sales_order_items: 167 records
Total: 17,756 records
```

### Prompt 2 — Linkage Analysis
```
[AI running deeper analysis to understand foreign key relationships]
```

**Key findings from analysis:**
```python
# Discovered key relationships:
# - SO.soldToParty = business_partners.customer (8/8 overlap)  
# - journal.referenceDocument = billing.billingDocument (64/80 match)
# - journal.accountingDocument = billing.accountingDocument (64/64)
# - payment.accountingDocument = journal.accountingDocument (120/120)
# - delivery.shippingPoint = plant.plant (5 unique plants)
# - SO items.material = product_descriptions.product (69/69 full coverage)
```

**Critical insight discovered:** `journal_entry.referenceDocument` is the correct field linking to `billingDocument`, NOT `accountingDocument`. This was a non-obvious relationship that required cross-table analysis.

---

## Phase 2: Architecture Decision

### Prompt 3 — Architecture Choice
```
see i want to use it as a real time working project not just the sample queries 
it should be to answer any query and also make sure you use the dataset file 
completely and must needed and instead of anthropic api i want to use groq api 
which is free change it to that
```

**AI Reasoning:**
- User wants: (1) real queries beyond samples, (2) complete dataset, (3) Groq API
- Decision: Self-contained single HTML file with all 17,756 records embedded
- LLM approach: Code generation (JS) instead of SQL — more flexible, no backend needed
- Graph: Canvas-based force-directed layout — no heavy dependencies

**Architecture chosen:**
```
Browser-only SPA
├── Full dataset embedded as JS (17,756 records, ~2.7MB)
├── Pre-computed graph (758 nodes, 904 edges)
├── Groq API for NL → JS code generation
├── Sandboxed JS execution: new Function('DATA', code)(DATA)
└── Canvas force-layout graph renderer
```

**Why code generation over SQL:**
- No backend database required
- LLM can express complex multi-table joins as JS
- Results are auditable (code shown to user)
- Flexible — any aggregation expressible in JS

**Why Groq (llama-3.3-70b):**
- Free tier available
- 128k context window — fits full schema + examples
- Fast inference (important for interactive UX)

---

## Phase 3: Graph Data Modeling

### Prompt 4 — Graph Construction
```python
# AI-generated graph builder analyzing all 13 tables
```

**Node types defined:**
| Type | Count | Key |
|------|-------|-----|
| Customer | 8 | business_partners.customer |
| SalesOrder | 100 | salesOrder |
| SalesOrderItem | 167 | salesOrder+salesOrderItem |
| Delivery | 86 | deliveryDocument |
| BillingDoc | 80 | billingDocument |
| JournalEntry | 123 | accountingDocument+item |
| Payment | 120 | accountingDocument+item |
| Product | 69 | material |
| Plant | 5 | plant (shipping points) |

**Edge types defined:**
```
PLACED_ORDER: Customer → SalesOrder (via soldToParty)
HAS_ITEM: SalesOrder → SalesOrderItem
REFERENCES_PRODUCT: SalesOrderItem → Product
SHIPS_FROM: Delivery → Plant (via shippingPoint)
BILLED_TO: Customer → BillingDoc (via soldToParty)
GENERATES_JOURNAL: BillingDoc → JournalEntry (via referenceDocument)
MADE_PAYMENT: Customer → Payment
CLEARED_BY: JournalEntry → Payment (via accountingDocument)
```

**Result:** 758 nodes, 904 edges

---

## Phase 4: Schema Documentation for LLM

### Prompt 5 — Schema Construction
```
[AI building complete schema documentation to embed in system prompt]
```

**Key prompting decisions:**
1. Include ALL field names (not just primary keys) so LLM can query any field
2. Document exact join paths with examples
3. Include broken flow detection patterns explicitly
4. Provide coded examples of complex queries (traces, joins, aggregations)
5. Specify data types (all strings, boolean exceptions, date format)

**Schema excerpt:**
```
IMPORTANT: journal_entry.referenceDocument = billing.billingDocument
(NOT accountingDocument — this was the key non-obvious relationship)
```

---

## Phase 5: HTML Application Build

### Prompt 6 — Application Architecture
```
[AI designing complete single-file HTML application]
```

**UI decisions:**
- Dark terminal aesthetic (`#080b12` background) — professional, data-tool feel
- JetBrains Mono for code/data, Inter for prose — clear hierarchy
- Left panel: graph (expandable), Right panel: chat (380px fixed)
- Filter chips on graph for entity type toggling
- Quick query buttons (18 examples covering all O2C scenarios)

**Groq integration:**
```javascript
const GROQ_API = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL = 'llama-3.3-70b-versatile';

// Headers required by Groq
headers: {
  'Content-Type': 'application/json',
  'Authorization': 'Bearer ' + key
}
```

**Key guardrail implementation:**
```javascript
// System prompt instruction:
"You ONLY answer questions about the O2C dataset. 
For any unrelated requests, respond with EXACTLY:
{\"offTopic\":true,\"message\":\"...\"}"

// Client-side handling:
if (parsed && parsed.offTopic) {
  addMsg('a', parsed.message);
}
```

**Sandbox execution:**
```javascript
try {
  result = new Function('DATA', '"use strict";' + parsed.jsCode)(DATA);
} catch(e) {
  err = e.message;
}
```

---

## Phase 6: Testing & Verification

### Test 1: Basic Count Query
**Query:** "What is the total net amount of all sales orders?"
**Generated JS:**
```javascript
return DATA.sales_order_headers.reduce((sum, so) => sum + parseFloat(so.totalNetAmount||0), 0).toFixed(2);
```
**Result:** Correct numeric value

### Test 2: Multi-table Join
**Query:** "Trace full O2C flow for billing document 90504274"
**Generated JS:**
```javascript
const bd = DATA.billing_document_cancellations.find(b => b.billingDocument === '90504274');
const je = DATA.journal_entry_items_accounts_receivable.filter(j => j.referenceDocument === '90504274');
const pay = DATA.payments_accounts_receivable.filter(p => je.some(j => j.accountingDocument === p.accountingDocument));
// ... etc
```
**Result:** Full flow trace returned correctly

### Test 3: Guardrail Test
**Query:** "What is the capital of France?"
**Expected:** Off-topic rejection
**Result:** `{"offTopic":true,"message":"This system is designed to answer questions related to the Order to Cash dataset only."}`
✅ Guardrail working correctly

### Test 4: Broken Flow Detection
**Query:** "Find all sales orders delivered but not yet billed"
**Generated JS:**
```javascript
return DATA.sales_order_headers
  .filter(so => so.overallDeliveryStatus === 'C' && 
    (so.overallOrdReltdBillgStatus === '' || so.overallOrdReltdBillgStatus === 'A'))
  .map(so => ({salesOrder: so.salesOrder, customer: so.soldToParty, amount: so.totalNetAmount, date: so.creationDate?.slice(0,10)}));
```
**Result:** Correctly identified orders with broken billing flow

### Test 5: Aggregation
**Query:** "Which customers have the highest total payment amounts?"
**Generated JS:**
```javascript
const totals = {};
DATA.payments_accounts_receivable.forEach(p => {
  if (!totals[p.customer]) totals[p.customer] = 0;
  totals[p.customer] += parseFloat(p.amountInTransactionCurrency || 0);
});
const bp = {};
DATA.business_partners.forEach(b => bp[b.customer] = b.businessPartnerFullName);
return Object.entries(totals).sort((a,b) => b[1]-a[1]).slice(0,8).map(([c,t]) => ({customer:c, name:bp[c]||'', total: t.toFixed(2)}));
```
**Result:** Correct ranked list

---

## Phase 7: Graph Visualization Debugging

### Issue 1: Nodes overlapping at start
**Fix:** Randomized initial positions with type-based cluster centers
```javascript
const cx = W * (0.12 + ((ti%3) * 0.3));
const cy = H * (0.2 + (Math.floor(ti/3) * 0.35));
```

### Issue 2: Force simulation too slow
**Fix:** Reduced MAX_SIM_STEPS to 300 with alpha decay
```javascript
const alpha = Math.max(0.005, 0.25 * (1 - simStep / SIM_MAX));
```

### Issue 3: Node labels cluttering graph
**Fix:** Only show labels on hover, selected, or highlighted nodes

---

## Key Prompts Used

### Most Important Prompt — Schema Documentation
The most critical prompt was asking the AI to analyze the exact foreign key relationships across all 13 tables, particularly:
```
"Show me all the ways to join billing_document_cancellations to 
journal_entry_items_accounts_receivable"
```
This revealed the `referenceDocument = billingDocument` link that was non-obvious.

### System Prompt Design Philosophy
The LLM system prompt was iteratively refined to:
1. Give explicit field-level documentation (not just table-level)
2. Include exact join patterns as worked examples
3. Specify data types precisely (all strings by default)
4. Include the `"use strict"` instruction for code hygiene

---

## Files Generated

| File | Purpose | Generated By |
|------|---------|--------------|
| `src/index.html` | Complete application | `src/build_html.py` |
| `src/build_html.py` | Build script | AI-written |
| `data/full_dataset.json` | All 17,756 records | AI extraction script |
| `data/graph.json` | 758 nodes, 904 edges | AI graph builder |
| `README.md` | Architecture docs | AI-written |
| `sessions/claude_session.md` | This file | AI session log |

---

## Summary

**Total development time:** ~3 hours  
**Lines of code:** ~1,200 (HTML/CSS/JS) + ~300 (Python build scripts)  
**AI assistance level:** High — architecture, data modeling, graph engine, LLM integration, styling  
**Manual work:** Dataset exploration strategy, relationship verification, schema documentation refinement

The most valuable AI contributions were:
1. **Cross-table relationship discovery** — automated FK analysis saved hours of manual inspection
2. **Force-directed graph from scratch** — complete physics simulation without libraries
3. **LLM system prompt engineering** — precise schema documentation for reliable code generation
4. **Guardrail design** — structured JSON response format for off-topic detection
