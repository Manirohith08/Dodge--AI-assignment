# Setup Instructions

## Quick Start (Local)

1. Download `src/index.html`
2. Open it in Chrome, Firefox, or Edge
3. Get a **free** Groq API key at [console.groq.com](https://console.groq.com)
4. Enter your key in the "Groq API Key" field at the top
5. Start asking questions!

No installation, no Node.js, no Python, no backend required.

---

## Rebuild from Source

If you want to regenerate the HTML from the raw dataset:

### Prerequisites
- Python 3.8+
- Raw dataset in `data/` folder (full_dataset.json and graph.json)

```bash
cd o2c-graph-intelligence
python3 src/build_html.py
```

Output: `src/index.html` (~3MB, fully self-contained)

---

## Deploy to GitHub Pages

```bash
# 1. Initialize repo
git init
git add .
git commit -m "feat: initial O2C graph intelligence app"

# 2. Push to GitHub
git remote add origin https://github.com/YOUR_USERNAME/o2c-graph-intelligence
git push -u origin main

# 3. Enable GitHub Pages
# → Go to Settings → Pages → Source: Deploy from branch → Branch: main → Folder: /src
# → Your app will be live at: https://YOUR_USERNAME.github.io/o2c-graph-intelligence/
```

---

## Deploy to Netlify (Instant)

1. Go to [netlify.com/drop](https://netlify.com/drop)
2. Drag and drop `src/index.html`
3. You'll get a live URL instantly (e.g., `https://random-name.netlify.app`)

---

## Groq API Setup

1. Sign up at [console.groq.com](https://console.groq.com) (free, no credit card)
2. Go to **API Keys** → **Create API Key**
3. Copy the key (starts with `gsk_...`)
4. Paste into the app's API key field

**Free tier limits:** 14,400 requests/day, 6,000 tokens/minute — more than enough for this use case.

---

## Browser Compatibility

| Browser | Status |
|---------|--------|
| Chrome 90+ | ✅ Full support |
| Firefox 88+ | ✅ Full support |
| Edge 90+ | ✅ Full support |
| Safari 14+ | ✅ Full support |
| Mobile | ⚠ Functional but graph interaction limited |
