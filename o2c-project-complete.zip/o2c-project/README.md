# O2C Graph Intelligence — Order to Cash

A graph-based data modeling and natural language query system for SAP Order-to-Cash process data.

---

## Live Demo

Open `src/index.html` in any modern browser. No server required — fully self-contained.

> For deployment: upload `src/index.html` to GitHub Pages, Netlify, or any static host.

---

## Project Structure

```
o2c-graph-intelligence/
├── src/
│   ├── index.html          # Complete application (self-contained, ~3MB)
│   └── build_html.py       # Build script that generates index.html from data
├── data/
│   ├── full_dataset.json   # All 17,756 records from 13 tables (embedded in HTML)
│   └── graph.json          # Pre-computed graph: 758 nodes, 904 edges
├── sessions/
│   └── claude_session.md   # AI coding session transcript
├── README.md
└── setup.md                # Setup instructions
```

---

## Architecture

### Stack
- **Frontend**: Vanilla HTML/CSS/JavaScript — zero dependencies, zero build step
- **Graph Rendering**: Custom canvas-based force-directed layout engine
- **LLM**: Groq API (`llama-3.3-70b-versatile`) — free tier
- **Storage**: All data embedded as JavaScript objects in the HTML file
- **Query Engine**: LLM generates JavaScript expressions executed in a sandboxed Function scope

### Why This Architecture?

| Decision | Rationale |
|----------|-----------|
| Single HTML file | Zero infrastructure — works offline, deployable on any static host |
| Groq API (free tier) | No cost, llama-3.3-70b is highly capable for structured queries |
| JS-based query engine | Safer than SQL injection; no backend needed; full JS expressiveness for joins/aggregations |
| Canvas-based graph | No heavy library dependency; full control over physics and rendering |
| Embedded data | All 17,756 records available instantly; no API calls for data; works offline |

---

## Data Model

### 13 Tables → Graph

| Table | Records | Graph Type |
|-------|---------|------------|
| business_partners | 8 | Customer nodes |
| sales_order_headers | 100 | SalesOrder nodes |
| sales_order_items | 167 | SalesOrderItem nodes |
| outbound_delivery_headers | 86 | Delivery nodes |
| billing_document_cancellations | 80 | BillingDoc nodes |
| journal_entry_items_accounts_receivable | 123 | JournalEntry nodes |
| payments_accounts_receivable | 120 | Payment nodes |
| product_descriptions | 69 | Product nodes |
| plants | 44 | Plant nodes |
| customer_company_assignments | 8 | Enriches Customer |
| customer_sales_area_assignments | 28 | Enriches Customer |
| product_plants | 200 | Product→Plant edges |
| product_storage_locations | 16,723 | Storage metadata |

**Total: 17,756 records**

### Key Relationships (Edges)
```
Customer ──PLACED_ORDER──▶ SalesOrder
SalesOrder ──HAS_ITEM──▶ SalesOrderItem
SalesOrderItem ──REFERENCES_PRODUCT──▶ Product
Delivery ──SHIPS_FROM──▶ Plant
Customer ──BILLED_TO──▶ BillingDoc
BillingDoc ──GENERATES_JOURNAL──▶ JournalEntry
  (via: journal.referenceDocument = billing.billingDocument)
Customer ──MADE_PAYMENT──▶ Payment
JournalEntry ──CLEARED_BY──▶ Payment
  (via: payment.accountingDocument = journal.accountingDocument)
```

### O2C Flow
```
Customer → Sales Order → Sales Order Items → Delivery → Billing Document → Journal Entry → Payment
```

---

## LLM Prompting Strategy

### Approach: Code Generation + Execution
Instead of asking the LLM to describe answers in prose, the system prompts it to generate JavaScript code that directly queries the embedded dataset. This ensures:
1. **Accuracy** — answers are always data-backed, never hallucinated
2. **Flexibility** — any query can be expressed as code, not just pre-defined queries
3. **Auditability** — users see the exact code that was executed

### Prompt Design
The system prompt includes:
1. **Full schema** with field names, types, and relationships
2. **Coded examples** of common query patterns (joins, aggregations, traces)
3. **Guardrail instruction** — any off-topic query returns a structured rejection
4. **Response format spec** — strict JSON with `jsCode`, `explanation`, `insight`

### Guardrails
Off-topic queries (general knowledge, coding help, creative writing) are rejected:
```json
{"offTopic": true, "message": "This system is designed to answer questions related to the Order to Cash dataset only."}
```

The LLM is told explicitly: "You ONLY answer questions about the O2C dataset."

### Query Execution Sandbox
```javascript
const result = new Function('DATA', '"use strict";' + jsCode)(DATA);
```
- The generated code only has access to the `DATA` object
- `"use strict"` prevents common JS pitfalls
- No `eval()`, no global scope pollution

---

## Setup Instructions

### Running Locally
1. Clone/download the repo
2. Open `src/index.html` in Chrome, Firefox, or Edge
3. Get a free Groq API key at [console.groq.com](https://console.groq.com)
4. Paste your key in the "Groq API Key" field
5. Ask any question about the O2C data

### Rebuilding from Source
If you want to rebuild the HTML from the raw dataset:
```bash
# Ensure dataset is in data/ folder
python3 src/build_html.py
# Output: src/index.html
```

### Deploying
**GitHub Pages:**
```bash
git init && git add . && git commit -m "init"
git branch -M main
git remote add origin https://github.com/YOUR_USER/o2c-graph
git push -u origin main
# Enable GitHub Pages → deploy from /src folder
```

**Netlify:** Drag and drop `src/index.html` to netlify.com/drop

---

## Features

### Graph Visualization
- **Force-directed layout** with physics simulation (758 nodes, 904 edges)
- **9 entity types** with distinct colors and sizes
- **Interactive**: pan, zoom, hover tooltips, click to select
- **Type filters**: toggle any entity type on/off
- **Query highlighting**: nodes referenced in query results are highlighted in blue
- **Fit-to-screen** button to see full graph

### Conversational Query Interface
- **18+ example queries** covering all key O2C analytical scenarios
- **Groq llama-3.3-70b** translates natural language to JavaScript queries
- **Live execution** against complete embedded dataset
- **Rich results**: tables, scalar values, code display
- **Business insights** generated for each query result
- **Conversation memory**: maintains context across turns (last 8 messages)
- **Node highlighting**: matched records highlighted on graph

### Example Queries Supported
- "Which products appear in the most billing documents?"
- "Trace full O2C flow for billing document 90504274"
- "Find all sales orders delivered but not yet billed"
- "Which customers have the highest total payment amounts?"
- "List all cancelled billing documents"
- "Show all journal entries linked to a billing document"
- "Find orders with broken/incomplete O2C flows"
- "Average order value by customer"
- Any free-form question about the dataset

---

## Evaluation Notes

| Criterion | Implementation |
|-----------|----------------|
| **Graph modeling** | 9 node types, 8 edge types, complete O2C relationships |
| **Database/storage choice** | Embedded JSON — zero-latency, offline-capable, no backend |
| **LLM integration** | Code-generation approach ensures data-backed answers |
| **Guardrails** | System-prompt-level + structured JSON rejection response |
| **Code quality** | Single-file, no dependencies, clean separation of concerns |
| **Visualization** | Custom canvas engine, force layout, interactive filters |
